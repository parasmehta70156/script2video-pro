package com.paras.generatedapp

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.paras.generatedapp.ui.theme.Script2VideoProTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private lateinit var snackbarHostState: SnackbarHostState

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            // Snackbar will be fired from Compose when action retried
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        snackbarHostState = SnackbarHostState()

        setContent {
            Script2VideoProTheme {
                val scope = rememberCoroutineScope()
                var scriptText by remember { mutableStateOf(TextFieldValue("")) }
                var isGenerating by remember { mutableStateOf(false) }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { padding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Script2Video Pro",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = scriptText,
                            onValueChange = { scriptText = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            label = { Text("Paste your video script here") },
                            placeholder = { Text("Enter script text...") }
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            enabled = !isGenerating && scriptText.text.isNotBlank(),
                            onClick = {
                                val hasPermission = hasStoragePermission()
                                if (!hasPermission && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                    requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Storage permission required to save video")
                                    }
                                } else {
                                    generateVideoFromScript(scope, scriptText.text) { message ->
                                        scope.launch {
                                            snackbarHostState.showSnackbar(message)
                                        }
                                    }
                                    isGenerating = true
                                }
                            }
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .padding(end = 8.dp),
                                    strokeWidth = 2.dp
                                )
                            }
                            Text(text = if (isGenerating) "Generating..." else "Generate Video")
                        }
                    }

                    LaunchedEffect(Unit) {
                        // Reset state when snackbar shows completion
                        snapshotFlow { isGenerating }.collect { generating ->
                            if (!generating) return@collect
                        }
                    }
                }
            }
        }
    }

    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            true
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun generateVideoFromScript(
        scope: CoroutineScope,
        script: String,
        onResult: (String) -> Unit
    ) {
        val ttsEngine = tts ?: run {
            onResult("Text-to-Speech not initialized")
            return
        }

        scope.launch(Dispatchers.IO) {
            try {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()

                val audioFile = File(downloadsDir, "script2video_tts.wav")
                val videoFile = File(downloadsDir, "script2video_output.mp4")

                // Synthesize TTS to file (API 21+)
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "script2videoUtterance")
                }
                val ttsResult = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ttsEngine.synthesizeToFile(script, params, audioFile, "script2videoUtterance")
                } else {
                    TextToSpeech.ERROR
                }

                if (ttsResult == TextToSpeech.ERROR) {
                    launch(Dispatchers.Main) { onResult("Failed to synthesize speech") }
                    return@launch
                }

                // Wait a bit for TTS to complete (simplistic; in production use UtteranceProgressListener)
                Thread.sleep(3000)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    createPlaceholderVideoWithAudio(audioFile, videoFile)
                    launch(Dispatchers.Main) { onResult("Video exported to: ${videoFile.absolutePath}") }
                } else {
                    launch(Dispatchers.Main) { onResult("Video generation requires Lollipop or higher") }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                launch(Dispatchers.Main) { onResult("Error: ${e.message}") }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createPlaceholderVideoWithAudio(audioFile: File, outputFile: File) {
        val width = 720
        val height = 1280
        val frameRate = 30
        val videoMimeType = MediaFormat.MIMETYPE_VIDEO_AVC
        val videoFormat = MediaFormat.createVideoFormat(videoMimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 2_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val videoEncoder = MediaCodec.createEncoderByType(videoMimeType)
        videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = videoEncoder.createInputSurface()
        videoEncoder.start()

        // Simplified: we do not actually draw frames onto the surface; this just produces empty video.
        // In a production app, use EGL/OpenGL or Canvas rendering on the Surface.

        val bufferInfo = MediaCodec.BufferInfo()
        var videoTrackIndex = -1
        var muxerStarted = false

        var generate = true
        while (generate) {
            val encoderStatus = videoEncoder.dequeueOutputBuffer(bufferInfo, 10000)
            when {
                encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    generate = false
                }
                encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (muxerStarted) throw RuntimeException("Format changed twice")
                    val newFormat = videoEncoder.outputFormat
                    videoTrackIndex = muxer.addTrack(newFormat)
                    muxer.start()
                    muxerStarted = true
                }
                encoderStatus >= 0 -> {
                    val encodedData: ByteBuffer? = videoEncoder.getOutputBuffer(encoderStatus)
                    if (encodedData == null) {
                        throw RuntimeException("encoderOutputBuffer $encoderStatus was null")
                    }
                    if (bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    videoEncoder.releaseOutputBuffer(encoderStatus, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        generate = false
                    }
                }
            }
        }

        videoEncoder.stop()
        videoEncoder.release()

        // For simplicity, we do NOT mux the audio into the video here. That requires reading
        // the WAV file, encoding to AAC, and adding as another track.

        muxer.stop()
        muxer.release()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }
}
