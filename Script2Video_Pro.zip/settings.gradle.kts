rootProject.name = "Script2VideoPro"
include(":app")
